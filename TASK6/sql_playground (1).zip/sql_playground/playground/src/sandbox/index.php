<?php include('header.html'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <div class="form-group">
                
                <div class="text-center">
                    <img src="static/console.png" alt="Logo" width="80" height="80" class="align-center" style='margin-top: 1em;'>
                    <h2>Interactive SQL Console</h2>
                </div>
                <p>SQL query <span id="sqlConsoleLength"></span></p>
                <textarea id="sqlConsole" class="form-control" rows="5"></textarea>
                <hr>
                Câu Query: <div id="sqlConsoleQuery" class="mt-3"></div>
                Kết quả: <div id="sqlConsoleResult" class="mt-3"></div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.html'); ?>

<script>
    // var sqlConsole = document.getElementById('sqlConsole');
    sqlConsole.addEventListener('input', function() {
        let query = sqlConsole.value;
        updateInputLength(query, 'sqlConsoleLength');
        displayElement('sqlConsoleQuery', query);
        history.replaceState({}, '', `?consoleQuery=${encodeURIComponent(query)}`);
        if (this.delayedQuery) clearTimeout(this.delayedQuery);
        this.delayedQuery = setTimeout(() => {
            submitQuery(query)
                .then(data => drawTable(data))
                .then(table => displayElement('sqlConsoleResult', table, 'text'))
                .catch((error) => {
                    console.error('Error:', error);
                });
        }, 500);
    });
    window.onload = function() {
        let urlParams = new URLSearchParams(window.location.search);
        let consoleQuery = urlParams.get('consoleQuery');
        if (consoleQuery) {
            sqlConsole.value = decodeURIComponent(consoleQuery);
            sqlConsole.dispatchEvent(new Event('input'));
        }
    }

    function processTokens(tokens) {
        // Access the token information and perform further processing
        tokens = tokens.filter(token => token.type == 'string');
        console.log(tokens);
    }
</script>