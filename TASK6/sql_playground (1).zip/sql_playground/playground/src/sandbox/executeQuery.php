<?php
header('Content-Type: application/json');

// Get the raw POST data
$data = json_decode(file_get_contents('php://input'), true);
$query = $data['query'];

try {
    // Database connection
    include('../basic/db.php');
    $mysqli = make_connection("plaintext_db");
    mysqli_set_charset($mysqli,"utf8");

    // Check connection
    if ($mysqli->connect_error) {
        throw new mysqli_sql_exception("Connection failed: " . $mysqli->connect_error);
    }

    // Attempt query execution
    if (!$result = $mysqli->query($query)) {
        throw new mysqli_sql_exception("Error executing query: " . $mysqli->error);
    }

    // Fetch all results
    $results = $result->fetch_all(MYSQLI_ASSOC);

    // Return the results
    echo json_encode($results);

} catch (mysqli_sql_exception $exception) {
    // Return the error as JSON
    echo json_encode(['error' => $exception->getMessage()]);
} finally {
    // Close connection
    if (isset($mysqli) && $mysqli instanceof mysqli) {
        $mysqli->close();
    }
}
?>
