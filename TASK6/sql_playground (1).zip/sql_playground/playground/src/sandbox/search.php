<?php include('header.html'); ?>
<div class="container">

    <div class="form-group">
        <div class="text-center">
            <img src="static/logo.png" alt="Logo" width="80" height="80" class="align-center" style='margin-top: 1em;'>
            <h2>Tìm kiếm tin tức </h2>
        </div>
        <label for="keyword">Keyword: <span id="keywordLength"></span></label>
        <input type="text" id="keyword" class="form-control">
        <div id="Content" class="mt-3"></div>
        <hr style='margin-top:5em'>
        <h3>Mục tiêu khai thác:</h3>
        <div id="checklist" class="list-group"></div><br>
        Câu truy vấn:
        <div id="searchQuery" class="mt-3"></div>
        Kết quả truy vấn:
        <div id="searchResult" class="mt-3"></div>
    </div>

</div>
<?php include('footer.html'); ?>
<script>
    let keyword = document.getElementById('keyword');
    [keyword].forEach(element => element.addEventListener('input', function() {
        checklistItems.forEach((item, index) => {
            taskDone(index, false);
        });
        updateInputLength(keyword.value, 'keywordLength');
        let query = `SELECT * FROM news WHERE content LIKE '%${keyword.value}%'`;
        displayElement('searchQuery', query);
        history.replaceState({}, '', `?keyword=${encodeURIComponent(keyword.value)}`);
        if (this.delayedQuery) clearTimeout(this.delayedQuery);
        this.delayedQuery = setTimeout(() => {
            submitQuery(query)
                .then(data => {
                    taskDone(0, true);

                    if (data.error) {
                        taskDone(0, 'error');
                    }

                    if (data.length == 0) {
                        updateMessage(`<div class="alert alert-dark" role="alert"><strong>Không tìm thấy kết quả nào</div>`);
                    }

                    if (data.length >= 1) {
                        updateMessage(`<div class="alert alert-dark" role="alert"><strong>Kết quả tìm thấy</strong><br>ID bài viết: ${data[0].id}<br>Nội dung: ${data[0].content}</div>`);

                        if (data[0].id == ADMIN_PASSWORD || data[0].content == ADMIN_PASSWORD) {
                            taskDone(3, true);
                        }
                    }

                    return drawTable(data);
                })
                .then(table => displayElement('searchResult', table, 'text'))
                .catch((error) => {
                    console.error('Error:', error);
                });
        }, 500);
    }));


    window.onload = function() {

        checklistItems = [{
                text: 'Bước 0: Câu query hợp lệ',
                checked: false
            },
            {
                text: 'Bước 1: Bạn đã thoát khỏi những dấu nháy đơn trong câu truy vấn.',
                checked: false
            },
            {
                text: 'Bước 2: Sử dụng cú pháp UNION SELECT để thao túng MySQL thực thi thêm một câu query',
                checked: false
            },
            {
                text: 'Bước 3: Dùng UNION SELECT để lấy password của tài khoản "admin" (Kết quả trả về 1 row duy nhất chứa password admin)',
                checked: false
            }
        ];
        renderChecklist();

        let urlParams = new URLSearchParams(window.location.search);
        let keyword = urlParams.get('keyword');
        if (keyword) {
            document.getElementById('keyword').value = decodeURIComponent(keyword);
            document.getElementById('keyword').dispatchEvent(new Event('input'));
        }

        submitQuery("SELECT password FROM users WHERE username='admin'").then(data => {
            ADMIN_PASSWORD = data[0].password;
        });
    }

    function processTokens(tokens) {
        tokens = tokens.slice(10); // skip the prefix part that is fixed
        console.log(tokens);
        string_tokens = tokens.filter(token => token.type == 'string');
        if (
            string_tokens.length == 1 &&
            string_tokens[0].content.slice(2, -2) == document.getElementById('keyword').value
        ) {
            taskDone(1, false);
        } else {
            taskDone(1);
        }

        for (var i = 0; i < tokens.length; i++) {
            if (tokens[i].type == "keyword")
                if (tokens[i].content.toLowerCase() == "union") {
                    if (tokens[i + 2] != undefined && tokens[i + 2].content != undefined && tokens[i + 2].content.toLowerCase() == "select") {
                        taskDone(2, true);
                    }
                }
        }
    }
</script>