function drawTable(data) {
    if (data.error) {
        return "[ERROR] " + data.error;
    }
    if (data.length == 0) {
        return 'No results (0 row)';
    }
    asciiArt = 'Total: ' + data.length + ' row(s)\n';
    if (data.length > 0) { // Get column widths
        let columnWidths = Object.keys(data[0]).map(key => key.length);
        for (let i = 0; i < data.length; i++) {
            Object.values(data[i]).forEach((value, j) => {
                if (String(value).length > columnWidths[j]) {
                    columnWidths[j] = String(value).length;
                }
            });
        }
        let sepLine = '+-' + columnWidths.map(w => '-'.repeat(w)).join('-+-') + '-+';
        asciiArt += sepLine + '\n';
        asciiArt += '| ' + Object.keys(data[0]).map((key, i) => key.padEnd(columnWidths[i])).join(' | ') + ' |\n';
        asciiArt += sepLine + '\n';
        for (let i = 0; i < data.length; i++) {
            asciiArt += '| ' + Object.values(data[i]).map((value, j) => String(value).padEnd(columnWidths[j])).join(' | ') + ' |\n';
        }
        asciiArt += sepLine;
    }
    return asciiArt;
}


function submitQuery(query) {
    return fetch('executeQuery.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            query: query
        })
    }).then(response => response.json());
}

function updateInputLength(input, element_id = 'inputLength') {
    let length = input.length;
    document.getElementById(element_id).innerText = "(length: "+length+")";
}

function displayElement(elementId, text, language = 'sql') {
    const element = document.getElementById(elementId);
    const tokens = Prism.tokenize(text, Prism.languages[language]);

    // Process the tokens as desired
    if (language != 'text') {
        processTokens(tokens);
    }

    element.innerHTML = `<pre><code class="language-${language}">${
        Prism.highlight(text, Prism.languages[language], language)
    }</code></pre>`;
    Prism.highlightAll();
}

function updateMessage(text, append = false) {
    const content = document.getElementById('Content');
    if(append)
        content.innerHTML += text;
    else
        content.innerHTML = text;
}

var checklistItems = [];

function taskDone(index, flag = true) {
    if (index >= 0 && index < checklistItems.length) {
        checklistItems[index].checked = flag;
        renderChecklist();
    }
}

function renderChecklist() {
    const checklistContainer = document.getElementById('checklist');
    checklistContainer.innerHTML = '';

    for (let i = 0; i < checklistItems.length; i++) {
        const item = checklistItems[i];
        const listItem = document.createElement('a');
        listItem.href = '#';
        listItem.className = 'list-group-item list-group-item-action';

        const icon = document.createElement('i');
        
        if (item.checked) {
            listItem.style.color = 'green';
            icon.className = 'far fa-check-square';
        } else {
            icon.className = 'far fa-square';
        }
        if (item.checked == 'error') {
            listItem.style.color = 'red';
        }

        listItem.appendChild(icon);
        listItem.appendChild(document.createTextNode(` ${
            item.text
        }`));
        checklistContainer.appendChild(listItem);
    }
    if (checklistItems.every(item => item.checked)) {
        updateMessage('<div class="alert alert-success" role="alert"><i class="fas fa-flag"></i> Chúc mừng bạn đã giải thành công bài tập</div>' , true);
    }

}