<?php include('header.html'); ?>
<div class="container">


    <div class="form-group">
        <div class="text-center">
            <img src="static/logo.png" alt="Logo" width="80" height="80" class="align-center" style='margin-top: 1em;'>
            <h2>Interactive SQL Login (level 1)</h2>
        </div>
        <label for="username">Username: <span id="usernameLength"></span></label>
        <input type="text" id="username" class="form-control">
        <label for="password">Password: <span id="passwordLength"></span></label>
        <input type="text" id="password" class="form-control">
        <div id="Content" class="mt-3"></div>
        <hr style='margin-top:5em'>
        <h3>Mục tiêu khai thác:</h3>
        <div id="checklist" class="list-group"></div><br>
        Câu truy vấn:
        <div id="loginQuery" class="mt-3"></div>
        Kết quả truy vấn:
        <div id="loginResult" class="mt-3"></div>
    </div>

</div>
<?php include('footer.html'); ?>
<script>
    let username = document.getElementById('username');
    let password = document.getElementById('password');
    [username, password].forEach(element => element.addEventListener('input', function() {
        checklistItems.forEach((item, index) => {
            taskDone(index, false);
        });
        updateInputLength(username.value, 'usernameLength');
        updateInputLength(password.value, 'passwordLength');
        let query = `SELECT * FROM users WHERE username='${username.value}' AND password='${password.value}'`;
        displayElement('loginQuery', query);
        history.replaceState({}, '', `?username=${encodeURIComponent(username.value)}&password=${encodeURIComponent(password.value)}`);
        if (this.delayedQuery) clearTimeout(this.delayedQuery);
        this.delayedQuery = setTimeout(() => {
            submitQuery(query)
                .then(data => {
                    taskDone(0, true);

                    if (data.error) {
                        taskDone(0, 'error');
                    }

                    if(data.length == 0){
                        updateMessage(`<div class="alert alert-danger" role="alert">Đăng nhập không thành công (No results: 0 row)</div>`);
                    }

                    if(data.length >= 1){
                        updateMessage(`<div class="alert alert-dark" role="alert">Chào mừng <strong>${data[0].username}</strong> đã trở lại website! Bạn có khỏe không?</div>`);
                    }

                    if (data.length == 1 && data[0].username == 'admin') {
                        taskDone(3, true);
                    } else {
                        taskDone(3, false);
                    }

                    return drawTable(data);
                })
                .then(table => displayElement('loginResult', table, 'text'))
                .catch((error) => {
                    console.error('Error:', error);
                });
        }, 500);
    }));


    window.onload = function() {

        checklistItems = [{
                text: 'Bước 0: Câu query hợp lệ',
                checked: false
            },
            {
                text: 'Bước 1: Bạn đã thoát khỏi những dấu nháy đơn trong câu truy vấn.',
                checked: false
            },
            {
                text: 'Bước 2: Sử dụng cú pháp comment để bỏ qua phần còn lại của câu truy vấn.',
                checked: false
            },
            {
                text: 'Bước 3: Đăng nhập như account admin (1 row duy nhất chứa username là "admin")',
                checked: false
            }
        ];
        renderChecklist();

        updateMessage(`<div class="alert alert-dark" role="alert">Bạn chưa đăng nhập</div>`);

        let urlParams = new URLSearchParams(window.location.search);
        let username = urlParams.get('username');
        let password = urlParams.get('password');
        if (username) {
            document.getElementById('username').value = decodeURIComponent(username);
            document.getElementById('username').dispatchEvent(new Event('input'));
        }
        if (password) {
            document.getElementById('password').value = decodeURIComponent(password);
            document.getElementById('password').dispatchEvent(new Event('input'));
        }

    }

    function processTokens(tokens) {
        tokens = tokens.slice(9); // skip the prefix part that is fixed
        // Access the token information and perform further processing
        string_tokens = tokens.filter(token => token.type == 'string');
        if (
            string_tokens.length == 2 &&
            string_tokens[0].content.slice(1, -1) == document.getElementById('username').value &&
            string_tokens[1].content.slice(1, -1) == document.getElementById('password').value
        ) {
            taskDone(1, false);
        } else {
            taskDone(1);
        }


        tokens.forEach(token => {
            if (token.type == 'comment') { // Tìm xem chữ này có trong user input không. 
                    taskDone(2, true);
            }
        });
    }
</script>