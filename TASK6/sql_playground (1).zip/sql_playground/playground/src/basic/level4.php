<?php
function checkValid($data)
{
    if (strpos($data, '"') !== false)
        return false;
    return true;
}

function loginHandler($username, $password)
{
    if (!checkValid($username) || !checkValid($password))
        return "Hack detected";

    try {
        include("db.php");
        $database = make_connection("hashed_db");

        $sql = "SELECT username FROM users WHERE username=LOWER(\"$username\") AND password=MD5(\"$password\")";
        $query = $database->query($sql);
        $row = $query->fetch_assoc(); // Get the first row

        if ($row === NULL)
            return "Wrong username or password"; // No result

        $login_user = $row["username"];
        if ($login_user === "admin")
            return "Wow you can log in as admin, here is your flag flag{44682b8def08e0fe9cdcb079e7db4dc0}, but how about <a href='level5.php'>THIS LEVEL</a>!";
        else
            return "You log in as $login_user, but then what? You are not an admin";
    } catch (mysqli_sql_exception $e) {
        return $e->getMessage();
    }
}

if (isset($_POST["username"]) && isset($_POST["password"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $message = loginHandler($username, $password);
}

include("static/html/login.html");
